NOTE:  readme.txt template -- do not remove empty entries, but you may
                              add entries for additional authors
------------------------------------------------------------------------------

Package name:   <leave blank>

DOI:  <leave blank>

Title: gmd: The Easy Way to Access the World’s Most Comprehensive Macroeconomic Database

Author 1 name: Karsten Müller
Author 1 from: National University of Singapore, Risk Management Institute, Singapore
Author 1 email: kmueller@nus.edu.sg

Author 2 name: Mohamed Lehbib
Author 2 from: National University of Singapore, Singapore
Author 2 email: lehbib@u.nus.edu

Author 3 name:  
Author 3 from:  
Author 3 email: 

Author 4 name:  
Author 4 from:  
Author 4 email: 

Author 5 name:  
Author 5 from:  
Author 5 email: 

Help keywords: gmd.sthlp

File list: gmd.ado gmd.sthlp gmd_examples.do gmd_examples.log

Notes: The gmd command downloads data directly from the Global Macro Database online repository and requires an internet connection. The command also requires the 'missings' package. To install it, type "ssc install missings". Examples in gmd_examples.do are fully reproducible with internet access and require the packages "binsreg" and "winsor2".